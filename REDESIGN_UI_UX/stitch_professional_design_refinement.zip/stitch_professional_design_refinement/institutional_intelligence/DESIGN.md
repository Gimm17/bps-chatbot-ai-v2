---
name: Institutional Intelligence
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#424751'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#727783'
  outline-variant: '#c2c6d3'
  surface-tint: '#125eaf'
  primary: '#00417f'
  on-primary: '#ffffff'
  primary-container: '#0058a9'
  on-primary-container: '#b7d0ff'
  inverse-primary: '#a8c8ff'
  secondary: '#984700'
  on-secondary: '#ffffff'
  secondary-container: '#fe852b'
  on-secondary-container: '#632c00'
  tertiary: '#6e2e00'
  on-tertiary: '#ffffff'
  tertiary-container: '#934000'
  on-tertiary-container: '#ffc2a3'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d5e3ff'
  primary-fixed-dim: '#a8c8ff'
  on-primary-fixed: '#001b3c'
  on-primary-fixed-variant: '#004689'
  secondary-fixed: '#ffdbc8'
  secondary-fixed-dim: '#ffb68a'
  on-secondary-fixed: '#321300'
  on-secondary-fixed-variant: '#743500'
  tertiary-fixed: '#ffdbca'
  tertiary-fixed-dim: '#ffb68f'
  on-tertiary-fixed: '#331200'
  on-tertiary-fixed-variant: '#773200'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 12px
  md: 16px
  lg: 24px
  xl: 32px
  2xl: 48px
  container-max: 1200px
  gutter: 24px
---

## Brand & Style

This design system is built for a government-affiliated AI assistant, requiring a visual language that balances institutional authority with modern accessibility. The brand personality is professional, data-driven, and trustworthy.

The design style follows a **Modern Corporate** approach, utilizing high-contrast typography and structured layouts to ensure information density remains readable. It avoids excessive decorative elements, opting instead for functional clarity. Key characteristics include:
- **Professionalism:** A disciplined use of whitespace and a restricted color palette to convey reliability.
- **Precision:** Sharp, consistent alignment and a clear information hierarchy that mirrors the accuracy of statistical data.
- **Accessibility:** High-contrast text and generous touch targets to accommodate a wide range of users, from researchers to the general public.

## Colors

The palette is anchored by the official BPS brand colors, optimized for digital interfaces.

- **Primary (#0058a9):** Used for primary actions, branding, and active navigation states. It represents stability and institutional trust.
- **Secondary/Accent (#f27c21):** Applied sparingly for interactive highlights, primary call-to-action buttons, and critical alerts. It provides a warm, energetic contrast to the primary blue.
- **Neutral/Text (#0f172a):** A deep navy used for primary headings and body text to improve legibility compared to pure black.
- **Background (#f8fafc):** A clean, cool-toned slate white that reduces eye strain while maintaining a modern, airy feel.
- **Semantic Colors:** Success (Green), Warning (Orange), and Error (Red) should follow standard accessibility ratios against the light background.

## Typography

The design system uses **Plus Jakarta Sans** for its modern, friendly, yet professional geometric qualities. 

- **Hierarchy:** Strong contrast between bold headings and regular body text is essential for skimming complex data reports.
- **Line Height:** Generous line heights are maintained (1.5x for body text) to ensure readability in long-form AI responses.
- **Letter Spacing:** Headlines utilize slight negative tracking to appear more cohesive, while small labels use positive tracking to ensure legibility at small scales.
- **Responsive Scaling:** Headline sizes scale down by approximately 15-20% on mobile devices to prevent awkward text wrapping.

## Layout & Spacing

The layout follows a **Fixed Grid** system for desktop and a **Fluid Grid** for mobile devices.

- **Grid System:** A 12-column grid is used for desktop (1200px max-width) with 24px gutters. On mobile, the system transitions to a 4-column fluid grid with 16px side margins.
- **Spacing Rhythm:** An 8pt linear scale (with 4px increments for micro-adjustments) governs all padding and margins. 
- **Density:** The design favors "Generous" spacing to maintain the professional, government-standard aesthetic. Information-heavy sections (like data tables) may switch to a "Compact" mode using the `sm` and `xs` tokens.
- **Alignment:** Content is generally center-aligned within containers, while text within cards remains left-aligned for optimal reading flow.

## Elevation & Depth

This design system uses **Tonal Layers** combined with **Ambient Shadows** to create a sense of hierarchy without overwhelming the user with heavy skeuomorphism.

- **Level 0 (Floor):** The base background (`#f8fafc`).
- **Level 1 (Cards/Containers):** White surfaces (`#ffffff`) with a subtle 1px border (`#e2e8f0`) and a soft, low-opacity shadow (e.g., `0 4px 6px -1px rgba(0, 0, 0, 0.05)`).
- **Level 2 (Interaction/Hover):** When an element is focused or hovered, the shadow deepens slightly, and the border color shifts to the primary blue at a low opacity.
- **Glassmorphism:** Reserved exclusively for top navigation bars or floating action headers, using a backdrop blur of 12px and 80% opacity white to maintain context of the content beneath.

## Shapes

The shape language is defined by **Rounded** corners to soften the institutional feel and make the AI assistant feel more approachable.

- **Standard Elements:** Buttons, input fields, and small cards use the base `rounded` token (8px/0.5rem).
- **Main Containers:** Large content cards and AI chat bubbles use `rounded-lg` (16px/1rem).
- **Avatars & Icons:** Often use `rounded-full` (pill-shaped) to distinguish human/bot identities from UI components.
- **Borders:** Use thin 1px strokes in light gray for most containers, ensuring they remain distinct from the background.

## Components

- **Buttons:** Primary buttons use the BPS Blue with white text. Floating Action Buttons (FAB) or high-priority chat triggers use the BPS Orange. All buttons feature a 8px corner radius and a 2px vertical padding offset for a balanced look.
- **Input Fields:** The chat input is a large, white, rounded-xl container with a subtle shadow. It includes a clear placeholder and an icon-based "send" button.
- **Cards:** Used for "Suggested Questions" or "Features." These feature a 1px border, 16px padding, and a transition effect on hover (slight lift and border color change).
- **AI Chat Bubbles:** The assistant's messages should be styled with a distinct, light-colored background (e.g., light blue tint) to differentiate them from user queries, which are often right-aligned or contained in distinct high-contrast containers.
- **Chips/Tags:** Used for data categories or filters. These use small font sizes (label-sm) and a light-gray background with a pill shape.
- **Icons:** Use a consistent "Linear" or "Outline" style with a 2px stroke weight to match the clean typography of Plus Jakarta Sans.